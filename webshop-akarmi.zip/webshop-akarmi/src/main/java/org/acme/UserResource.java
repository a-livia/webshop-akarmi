package org.acme;

import org.jboss.resteasy.annotations.jaxrs.PathParam;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
@Path("/users")
public class UserResource {

    private boolean isAuthenticated = true;

    @GET
    @Path("/{userId}")
    public Response getUserData(@PathParam String id) {
        if (isAuthenticated==true){
        return Response.status(200).build();
        }
        return Response.status(401).build();
    }

    @PUT
    @Path("/{userId}")
    public Response modifyUserData(@PathParam String userId, String user) {
        return Response.status(200).build();
    }

    @GET
    @Path("/{userId}/addresses")
    public Response getUserAddresses(@PathParam String userId) {
        return Response.status(200).build();
    }

    @POST
    @Path("/{userId}/addresses")
    public Response newAddress(@PathParam String userId, String address) {
        return Response.status(201).build();
    }

    @PUT
    @Path("/{userId}/addresses/{aId}")
    public Response modifyAddress(@PathParam String userId, @PathParam String aId, String address) {
        return Response.status(200).build();
    }

    @DELETE
    @Path("/{userId}/addresses/{aId}")
    public Response deleteAddress(@PathParam String userId, @PathParam String aId) {
        if (isAuthenticated==true && aId.equals("1")){
            return Response.status(200).build();
        }
        return Response.status(401).build();
    }

    @GET
    @Path("/{userId}/purchases")
    public Response getUserPurchases(@PathParam String id) {
        return Response.status(200).build();
    }

    @GET
    @Path("/{userId}/carts")
    public Response getUserCart(@PathParam String id) {
        return Response.status(200).build();
    }

    @DELETE
    @Path("/{userId}/carts/{itemId}")
    public Response deleteItemFromCart(@PathParam String id, @PathParam String itemId) {
        return Response.status(200).build();
    }
}
