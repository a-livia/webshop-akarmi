package org.acme;

import org.jboss.resteasy.annotations.jaxrs.PathParam;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
@Path("/purchases")
public class PurchaseResource {

    @GET
    @Path("/{purchaseId}")
    public Response getPurchase(@PathParam String purchaseId) {
        return Response.status(200).build();
    }

    @DELETE
    @Path("/{purchaseId}")
    public Response deletePurchase(@PathParam String purchaseId) {
        return Response.status(200).build();
    }

    @POST
    @Path("/{userId}")
    public Response checkOut(@PathParam String userId) {
        return Response.status(200).build();
    }
}
