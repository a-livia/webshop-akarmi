package org.acme;

import org.jboss.resteasy.annotations.jaxrs.PathParam;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
@Path("/categories")
public class CategoryResource {

    @GET
    public Response getCategories() {
        return Response.status(200).build();
    }

    @GET
    @Path("/{categoryId}/{pageNumber}")
    public Response getItemsOfCategory(@PathParam String categoryId, @PathParam int pageNumber) {
        return Response.status(200).build();
    }
}
