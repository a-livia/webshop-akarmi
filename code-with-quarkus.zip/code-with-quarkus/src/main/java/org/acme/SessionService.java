package org.acme;

import io.quarkus.security.AuthenticationFailedException;

import javax.enterprise.context.ApplicationScoped;
import java.time.LocalDateTime;
import java.util.*;

@ApplicationScoped
public class SessionService {
    private static final Map<String, String> systems = Map.of(
            "VEKTOR", "abc",
            "TM", "xyz"
    );

    private static final Map<String, List<Session>> sessions;

    static {
        sessions = new HashMap<>();
        sessions.put("VEKTOR", new ArrayList<>());
        sessions.put("TM", new ArrayList<>());
    }

    public static class Session {
        private UUID sessionId;
        private final LocalDateTime expiration = LocalDateTime.now().plusSeconds(60);

        public UUID getSessionId() {
            return sessionId;
        }

        public void setSessionId(UUID sessionId) {
            this.sessionId = sessionId;
        }

        public LocalDateTime getExpiration() {
            return expiration;
        }
    }

    public Session createNewSession(String apiKey) {
        var systemName = findSystemName(apiKey);

        var sessionId = UUID.randomUUID();
        var session = new Session();
        session.setSessionId(sessionId);

        sessions.computeIfPresent(systemName, (key, oldList) -> {
            oldList.add(session);
            return oldList;
        });

        return session;
    }

    public boolean invalidateSession(String apiKey, UUID sessionId) {
        var systemName = findSystemName(apiKey);

        var sessionList = findSystemSessions(systemName);

        var sessionToDelete = sessionList.stream()
                .filter(session -> session.getSessionId().equals(sessionId) && session.getExpiration().isBefore(LocalDateTime.now()))
                .findFirst();

        if (sessionToDelete.isPresent()) {
            sessionList.remove(sessionToDelete);
            return true;
        }
        return false;
    }

    public boolean checkSession(String apiKey, UUID sessionId) {
        var systemName = findSystemName(apiKey);

        var sessionList = findSystemSessions(systemName);

        var sessionCheck = sessionList.stream()
                .filter(session -> session.getSessionId().equals(sessionId) && session.getExpiration().isAfter(LocalDateTime.now()))
                .findFirst();

        if (sessionCheck.isPresent()) {
            return true;
        }
        return false;
    }

    public String findSystemName(String apiKey) {
        var systemName = systems.entrySet().stream()
                .filter(entry -> apiKey.equals(entry.getValue()))
                .findFirst()
                .map(Map.Entry::getKey)
                .orElseThrow();
        return systemName;
    }

    public List<Session> findSystemSessions(String systemName) {
        var sessionList = (sessions.entrySet().stream()
                .filter(entry -> systemName.equals(entry.getKey()))
                .findFirst()
                .map(Map.Entry::getValue)
                .orElseThrow());
        return sessionList;
    }
}
