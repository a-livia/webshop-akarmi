package org.acme;


import io.quarkus.security.AuthenticationFailedException;

import javax.inject.Inject;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.util.UUID;

@Path("/sessions")
public class SessionResource {

    @Inject
    SessionService sessionService;

    @POST
    @Path("{apiKey}")
    public Response newSession(@PathParam("apiKey") @NotNull String apiKey) {
        var session = sessionService.createNewSession(apiKey);
        return Response.created(null).entity(session).build();
    }

    @DELETE
    @Path("{apiKey}/{sessionId}")
    public Response invalidateSession(@PathParam("apiKey") @NotNull String apiKey, @PathParam("sessionId") UUID sessionId) {
        var session = sessionService.invalidateSession(apiKey, sessionId);
        if(session == false){
            throw new AuthenticationFailedException("Invalid session id");
        }
        return Response.status(200).entity(session).build();
    }

}
