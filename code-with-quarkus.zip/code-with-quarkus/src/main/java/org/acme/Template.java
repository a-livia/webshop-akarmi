package org.acme;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.MonthDay;
import java.time.temporal.ChronoUnit;

public class Template {
    private Long id = 1L;
    private String name = "FooBar";
    private LocalDateTime validStart = LocalDateTime.now().minus(5, ChronoUnit.DAYS);
    private LocalDateTime getValidEnd = LocalDateTime.now().plus(5, ChronoUnit.MONTHS);

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDateTime getValidStart() {
        return validStart;
    }

    public void setValidStart(LocalDateTime validStart) {
        this.validStart = validStart;
    }

    public LocalDateTime getGetValidEnd() {
        return getValidEnd;
    }

    public void setGetValidEnd(LocalDateTime getValidEnd) {
        this.getValidEnd = getValidEnd;
    }
}
