package org.acme;


import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.Collections;
import java.util.List;

@Produces(MediaType.APPLICATION_JSON)
@Path("/users")
public class UserResource {
    @GET
    @Path("/templates")
    public List<Template> getTemplates() {
        return Collections.singletonList(new Template());
    }

    @GET
    @Path("/{userId}")
    @Produces(MediaType.TEXT_PLAIN)
    public Response getUserData(@PathParam("userId") String userId) {
        if (userId.length() == 1) {
            return Response.status(200).entity("\nGiven id is: " + userId).build();
        }
        throw new ForbiddenException();
    }

    @PUT
    @Path("/{userId}")
    public Response modifyUserData(@PathParam("userId") String userId, String user) {
        return Response.status(200).build();
    }

    @GET
    @Path("/{userId}/addresses")
    public Response getUserAddresses(@NotNull @Size(min = 5) @PathParam("userId") String userId) {
        return Response.status(200).build();
    }

    @POST
    @Path("/{userId}/addresses")
    public Response newAddress(@PathParam("userId") String userId, String address) {
        return Response.status(201).build();
    }

    @PUT
    @Path("/{userId}/addresses/{aId}")
    public Response modifyAddress(@PathParam("userId") String userId, @PathParam("aId") String aId, String address) {
        return Response.status(200).build();
    }

    @DELETE
    @Path("/{userId}/addresses/{aId}")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deleteAddress(@PathParam("userId") String userId, @PathParam("aId") String aId) {
        if (aId.equals("1")) {
            return Response.status(200).entity("\nDeleted").build();
        }
        return Response.status(401).entity("\nFailed").build();
    }

    @GET
    @Path("/{userId}/purchases")
    public Response getUserPurchases(@PathParam("userId") String userId) {
        return Response.status(200).build();
    }

    @GET
    @Path("/{userId}/carts")
    public Response getUserCart(@PathParam("userId") String userId) {
        return Response.status(200).build();
    }

    @DELETE
    @Path("/{userId}/carts/{itemId}")
    public Response deleteItemFromCart(@PathParam("userId") String userId, @PathParam("itemId") String itemId) {
        return Response.status(200).build();
    }
}
