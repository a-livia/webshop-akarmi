package org.acme;

import org.jboss.resteasy.annotations.jaxrs.PathParam;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Produces(MediaType.APPLICATION_JSON)
@Path("/items")
public class ItemResource {

    @GET
    public Response getItems() {
        return Response.status(200).build();
    }

    @GET
    @Path("/{itemId}")
    public Response getItem(@PathParam String itemId) {
        return Response.status(200).build();
    }

    @PUT
    @Path("/{itemId}/addToCart")
    public Response addToCart(@PathParam String itemId, String item) {
        return Response.status(200).build();
    }

    @GET
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    @Path("/{itemId}/images")
    public Response getItemImages(@PathParam String itemId) {
        return Response.status(200).build();
    }


    @GET
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    @Path("/{itemId}/images/{imageId}")
    public Response getItemImages(@PathParam String itemId, @PathParam String imageId) {
        return Response.status(200).build();
    }
}
